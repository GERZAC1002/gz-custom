# Build Instructions

Build instructions are available on [the website](https://polymc.org/wiki/development/build-instructions/).

If you would like to contribute or fix an issue with the Build instructions you can do so [here](https://github.com/PolyMC/polymc.github.io/blob/master/src/wiki/development/build-instructions.md).
