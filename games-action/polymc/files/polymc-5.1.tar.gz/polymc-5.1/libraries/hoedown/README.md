Hoedown
=======

This is Hoedown 3.0.2, taken from [the hoedown github repo](https://github.com/hoedown/hoedown).

`Hoedown` is a revived fork of [Sundown](https://github.com/vmg/sundown),
the Markdown parser based on the original code of the
[Upskirt library](http://fossil.instinctive.eu/libupskirt/index)
by Natacha Porté.
