#ifndef TOML_IMPLEMENTATION
#define TOML_IMPLEMENTATION
#endif
#ifndef TOML_HEADER_ONLY
#define TOML_HEADER_ONLY 0
#endif

#include <toml++/toml.h>
