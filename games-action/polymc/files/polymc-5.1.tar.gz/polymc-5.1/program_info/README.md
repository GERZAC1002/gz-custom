# PolyMC Program Info

This is PolyMC's program info which contains information about:

- Application name and logo (and branding in general)
- Various URLs and API endpoints
- Desktop file
